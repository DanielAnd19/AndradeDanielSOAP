/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Controller.TestWS;
import Vista.CuentaAbierta;
import Vista.Formulario;
import Vista.FormularioRegistro;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Scanner;
import javax.swing.Timer;
import ws.ConversionSW;
import ws.ConversionSW_Service;

/**
 *
 * @author Danie
 */
public class controlerUsuario {

    FormularioRegistro fomrU;
    ConversionSW cliente;

    public controlerUsuario(FormularioRegistro fomrU, ConversionSW cliente) {
        this.fomrU = fomrU;
        this.cliente = cliente;
        fomrU.setLocationRelativeTo(null);
        fomrU.setVisible(true);
        fomrU.setTitle("Registro");
    }

    public void iniciarcontrol() {
        fomrU.getjButton1().addActionListener(l -> registrarU());
    }

    private void registrarU() {

        String user = fomrU.getTxtusuario().getText();
        String password = fomrU.getTxtpas().getText();
        String password2 = fomrU.getTxtpass2().getText();
        double saldo = Double.parseDouble(fomrU.getTxtcant().getText());

        String mensaje = cliente.registrar(user, password, password2, saldo);

        if (mensaje.equals("Registro exitoso")) {
            System.out.println("Registro exitoso");
            // Aquí puedes realizar otras acciones después de un registro exitoso
            fomrU.getjLabel6().setText("REGISTRADO CORRECTAMENTE");

        } else {
            System.out.println("Registro fallido: " + mensaje);
            // Aquí puedes manejar la respuesta de registro fallido
        }
    }

    private void abrir() {

        FormularioRegistro registro = new FormularioRegistro();
        controlerUsuario controllerU = new controlerUsuario(registro, cliente);
        controllerU.iniciarcontrol();
    }
}
