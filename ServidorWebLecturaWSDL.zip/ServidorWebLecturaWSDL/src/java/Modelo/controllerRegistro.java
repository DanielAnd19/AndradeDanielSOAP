/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Vista.CuentaAbierta;
import Vista.Formulario;
import Vista.FormularioRegistro;
import ws.ConversionSW;

/**
 *
 * @author Danie
 */
public class controllerRegistro {

    Formulario loginU;
    ConversionSW cliente;
    CuentaAbierta ca;

    public controllerRegistro(Formulario form, ConversionSW cliente) {
        this.loginU = form;
        this.cliente = cliente;
        form.setLocationRelativeTo(null);
        form.setVisible(true);
        form.setTitle("Iniciar Sesion");
    }

    public void iniciarCOntrol() {
        loginU.getBtnregistrar().addActionListener(l -> abrirRegistro());
        loginU.getBtnlogin().addActionListener(l -> logeo());
    }

    private void abrirRegistro() {
        FormularioRegistro registro = new FormularioRegistro();
        controlerUsuario controllerU = new controlerUsuario(registro, cliente);
        controllerU.iniciarcontrol();
    }

    private void logeo() {

        String user = loginU.getTxtusuario().getText();
        String password = loginU.getTxtpass().getText();

        String mensaje = cliente.logeo(user, password);

        if (mensaje.equals("BIENVENIDO")) {
            System.out.println("Registro exitoso");
            CuentaAbierta cuentaAbierta = new CuentaAbierta();
            cuentaAbierta.setVisible(true);
            loginU.setVisible(false);

            ControllerCuentaA controllerCuentaA = new ControllerCuentaA(cuentaAbierta);
            controllerCuentaA.iniciarControl(user);

        } else {
            System.out.println("Registro fallido: " + mensaje);
            loginU.getjLabel5().setText("FALLO AL INICIAR SESION");

        }

    }

}
