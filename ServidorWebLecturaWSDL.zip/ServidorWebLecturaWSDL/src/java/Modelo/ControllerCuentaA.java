/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Vista.CuentaAbierta;
import ws.ConversionSW;

/**
 *
 * @author Danie
 */
public class ControllerCuentaA {

    private CuentaAbierta cuentaAbierta;

    public ControllerCuentaA(CuentaAbierta cuentaAbierta) {
        this.cuentaAbierta = cuentaAbierta;
    }

    public void iniciarControl(String nombreUsuario) {
        cuentaAbierta.mostrarNombreUsuario(nombreUsuario);
    }
 
    
}
