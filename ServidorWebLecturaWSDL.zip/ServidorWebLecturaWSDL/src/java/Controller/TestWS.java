/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelo.controlerUsuario;
import Modelo.controllerRegistro;
import Vista.CuentaAbierta;
import Vista.Formulario;
import Vista.FormularioRegistro;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.Timer;
import ws.ConversionSW;
import ws.ConversionSW_Service;

/**
 *
 * @author Danie
 */
public class TestWS {

    public static void main(String[] args) {
        ConversionSW_Service service = new ConversionSW_Service();
        ConversionSW cliente = service.getConversionSWPort();
        Formulario logIn = new Formulario();
        controllerRegistro controllerUsuario = new controllerRegistro(logIn,cliente);
        controllerUsuario.iniciarCOntrol();

    }
}
