/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import MOdel.modelUsuario;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Danie
 */
@WebService(serviceName = "ConversionSW")
public class ConversionSW {

    private Double valor, valor2;

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "euroDOLAR")
    public Double euroDOLAR(@WebParam(name = "euroDOLAR") double euroDOLAR) {
        //TODO write your implementation code here:
        return euroDOLAR * 1.15;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Suma")
    public Double Suma(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1 + num2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "resta")
    public Double resta(@WebParam(name = "res1") double res1, @WebParam(name = "res2") double res2) {
        //TODO write your implementation code here:
        return res1 - res2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "multiplicacion")
    public Double multiplicacion(@WebParam(name = "mul1") double mul1, @WebParam(name = "mul2") double mul2) {
        //TODO write your implementation code here:
        return mul1 * mul2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "division")
    public Double division(@WebParam(name = "div") double div, @WebParam(name = "div2") double div2) {
        //TODO write your implementation code here:
        return div / div2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "controlAcceso")
    public Boolean controlAcceso(@WebParam(name = "usu") String usu, @WebParam(name = "pass") String pass) {
        //TODO write your implementation code here:
        if (usu.equals("andy2002") && pass.equals("2002")) {
            return true; // Inicio de sesión válido
        }

        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Aceleracion")
    public Double Aceleracion(@WebParam(name = "velocidadinicial") double velocidadinicial, @WebParam(name = "velocidadfinal") double velocidadfinal, @WebParam(name = "tiempo") double tiempo) {
        //TODO write your implementation code here:

        valor = velocidadfinal - velocidadinicial;
        valor2 = valor / tiempo;

        return valor2;

    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "volumen")
    public Double volumen(@WebParam(name = "radio") double radio, @WebParam(name = "altura") double altura) {
        //TODO write your implementation code here:
        return Math.PI * Math.pow(radio, 2) * altura;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "densidad")
    public Double densidad(@WebParam(name = "masa") double masa, @WebParam(name = "volumen") double volumen) {
        //TODO write your implementation code here:
        return masa / volumen;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "velocidad")
    public Double velocidad(@WebParam(name = "distancia") double distancia, @WebParam(name = "tiempo") double tiempo) {
        //TODO write your implementation code here:
        return distancia / tiempo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "login")
    public String login(@WebParam(name = "usuario") String usuario, @WebParam(name = "pass") String pass, @WebParam(name = "saldo") double saldo) {
        //TODO write your implementation code here:
        modelUsuario modU = new modelUsuario();
        String mensaje = "";

        modU.setUsuario(usuario);
        modU.setPass(pass);
        modU.setSaldo(saldo);

//        if (usuarioExiste(usuario)) {
//            mensaje = "El usuario ya existe en la base de datos";
//        } else if (modU.setRegistro()) {
//            mensaje = "Registro exitoso";
//        } else {
//            mensaje = "Error al registrar";
//        }
        return mensaje;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "registrar")
    public String registrar(@WebParam(name = "usu") String usu, @WebParam(name = "pass") String pass, @WebParam(name = "pass2") String pass2, @WebParam(name = "cant") double cant) {
        //TODO write your implementation code here:
        modelUsuario mu = new modelUsuario();
        String mensaje = "";
        try {

            if (!usu.isEmpty() && !pass.isEmpty() && !pass2.isEmpty()) {
                if (!mu.VerificarUnico(usu)) {
                    if (pass.equals(pass2)) {
                        mu.setUsuario(usu);
                        mu.setPass(pass);
                        mu.setSaldo(cant);

                        if (mu.setRegistro()) {
                            mensaje = "Registro exitoso";
                            System.out.println("Registro");
                        } else {
                            mensaje = "Registro fallido";
                        }
                    } else {
                        mensaje = "Escriba correctamente su contraseña";
                    }
                } else {
                    mensaje = "El nombre de uruario ya existe";
                }
            } else {
                mensaje = "El nombre esta vacio";
            }
        } catch (Exception e) {
        }
        return mensaje;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "logeo")
    public String logeo(@WebParam(name = "usu") String usu, @WebParam(name = "pass") String pass) {
        //TODO write your implementation code here:
        modelUsuario mu = new modelUsuario();
        String mensaje = "";
        if (mu.VerificarUnico(usu) && mu.VerificarUnicoPass(pass)) {

            mu.setUsuario(usu);
            mu.setPass(pass);

            mensaje = "BIENVENIDO";
        } else {
            mensaje = "El usuario no existe";
        }
        return mensaje;
    }
}
