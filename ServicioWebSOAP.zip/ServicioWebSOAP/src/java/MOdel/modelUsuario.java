/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MOdel;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Danie
 */
public class modelUsuario extends Usuario {

    ModelConexion mpgc = new ModelConexion();

    public boolean setRegistro() {
        String sql = "INSERT INTO public.cuenta(\n"
                + "	usuario, pass, saldo)\n"
                + "	VALUES ('" + getUsuario()+ "', '" + getPass()+ "', " + getSaldo() + ");";
        return mpgc.accion(sql);
    }

    public boolean updateRegistro(int id) {
        String sql;
        sql = "UPDATE cuenta "
                + "SET saldo='" + getSaldo() + "' "
                + "WHERE zapato.id =" + id + ";";
        return mpgc.accion(sql);
    }

    public boolean VerificarUnico(String usu) {
        boolean ban = false;

        int cont = 0;
        String sql = "SELECT count(*)\n"
                + "	FROM public.cuenta where (usuario='" + usu + "');";
        ResultSet rs = mpgc.consulta(sql);
        try {
            while (rs.next()) {
                cont = rs.getInt(1);
            }

            if (cont > 0) {
                ban = true;
            }
        } catch (SQLException e) {
            Logger.getLogger(modelUsuario.class.getName()).log(Level.SEVERE, null, e);
        }
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(modelUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ban;
    }
    
        public boolean VerificarUnicoPass(String pass) {
        boolean ban = false;

        int cont = 0;
        String sql = "SELECT count(*)\n"
                + "	FROM public.cuenta where (pass='" + pass + "');";
        ResultSet rs = mpgc.consulta(sql);
        try {
            while (rs.next()) {
                cont = rs.getInt(1);
            }

            if (cont > 0) {
                ban = true;
            }
        } catch (SQLException e) {
            Logger.getLogger(modelUsuario.class.getName()).log(Level.SEVERE, null, e);
        }
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(modelUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ban;
    }
}
