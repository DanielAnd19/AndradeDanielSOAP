/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MOdel;

/**
 *
 * @author Danie
 */
public class Usuario {

    private int id;
    private String usuario;
    private String pass;
    private Double saldo;

    public Usuario() {
    }

    public Usuario(int id, String usuario, String pass, Double saldo) {
        this.id = id;
        this.usuario = usuario;
        this.pass = pass;
        this.saldo = saldo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
    
}
